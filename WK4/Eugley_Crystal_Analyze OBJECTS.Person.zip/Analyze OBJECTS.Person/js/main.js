// Crystal Eugley
// 4/29/2015
// ANALYZE! OBJECTS.Person Week 4

/* PSEUDO-CODE */


/*Create and array
    In the array include 5 names

Next create a for loop
    In the for loop add Math.random() so that the five names from the
    above array will be randomly selected when the for loop runs.

    Create a function() called populateHTML
        This function will populate the selected name from the array on the
        webpage.

    Create the function so it will not display duplicated names.

    Set up a runUpdate() function
        Run this code 30 times per second
 */