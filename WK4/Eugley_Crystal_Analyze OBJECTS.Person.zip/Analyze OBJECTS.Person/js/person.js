// Crystal Eugley
// 4/29/2015
// ANALYZE OBJECTS.Person

/* PSUEDO - CODE FOR PERSON.JS

Add Person object to go with main.js file

The Person object needs for constructors
    name    This is the name of the person
    action  States what the person is actively doing
    job     set from the jobs array
    row

    Set up update()function
        This will change the action of the person every so often.
        Should be set every 5 seconds or so and be displayed in HTML
        column 3
 */
